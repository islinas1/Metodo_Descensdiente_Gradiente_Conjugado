"""
Cómo usar los iconos en Streamlit
==================================
Hay 3 formas de usar los iconos SVG/PNG en tu app.
Elige la que más te convenga.
"""

import streamlit as st
import base64
import os

# ═══════════════════════════════════════════════
# MÉTODO 1: st.image() — El más simple
# ═══════════════════════════════════════════════
# Funciona con SVG y PNG. Solo ajusta el ancho.

st.image("iconos/analisis_estructural.svg", width=80)
st.markdown("**Análisis Estructural**")

# O con PNG:
st.image("iconos/png/analisis_estructural.png", width=80)


# ═══════════════════════════════════════════════
# MÉTODO 2: HTML inline con base64 — Para tarjetas
# ═══════════════════════════════════════════════
# Convierte la imagen a base64 y la incrusta en HTML.
# Esto permite ponerla dentro de tarjetas con diseño.

def icono_base64(ruta, ancho=60):
    """Carga una imagen y la devuelve como tag HTML en base64."""
    ext = os.path.splitext(ruta)[1].lower()
    mime = "image/svg+xml" if ext == ".svg" else "image/png"
    with open(ruta, "rb") as f:
        data = base64.b64encode(f.read()).decode()
    return f'<img src="data:{mime};base64,{data}" width="{ancho}" style="display:block; margin:0 auto 0.8rem auto;"/>'


# Ejemplo de tarjeta con icono:
icono_html = icono_base64("iconos/png/machine_learning.png", ancho=70)
st.markdown(f"""
<div style="
    background: rgba(255,255,255,0.03);
    border: 1px solid rgba(255,255,255,0.08);
    border-radius: 14px;
    padding: 1.5rem;
    text-align: center;
">
    {icono_html}
    <strong>Machine Learning</strong><br>
    <small style="color:#8888aa;">Optimización de funciones de pérdida</small>
</div>
""", unsafe_allow_html=True)


# ═══════════════════════════════════════════════
# MÉTODO 3: Función reutilizable para tarjetas
# ═══════════════════════════════════════════════
# La forma más limpia para usar en toda la app.

def tarjeta_con_icono(ruta_icono, titulo, descripcion, ancho_icono=60):
    """Genera una tarjeta HTML con icono, título y descripción."""
    icono = icono_base64(ruta_icono, ancho_icono)
    st.markdown(f"""
    <div style="
        background: rgba(255,255,255,0.03);
        border: 1px solid rgba(255,255,255,0.08);
        border-radius: 14px;
        padding: 1.5rem;
        text-align: center;
        height: 100%;
    ">
        {icono}
        <strong>{titulo}</strong><br>
        <small style="color:#8888aa;">{descripcion}</small>
    </div>
    """, unsafe_allow_html=True)


# Uso:
col1, col2, col3 = st.columns(3)
with col1:
    tarjeta_con_icono("iconos/png/analisis_estructural.png",
                      "Análisis Estructural",
                      "Elementos finitos en edificios y puentes")
with col2:
    tarjeta_con_icono("iconos/png/dinamica_fluidos.png",
                      "Dinámica de Fluidos",
                      "Ecuaciones de Navier-Stokes")
with col3:
    tarjeta_con_icono("iconos/png/circuitos_electricos.png",
                      "Circuitos Eléctricos",
                      "Redes con miles de nodos")


# ═══════════════════════════════════════════════
# MAPA DE ICONOS DISPONIBLES
# ═══════════════════════════════════════════════
"""
Iconos disponibles (SVG + PNG):

📁 iconos/
├── analisis_estructural.svg    🏗️ Edificio con fuerzas
├── dinamica_fluidos.svg        🌊 Ondas de flujo
├── circuitos_electricos.svg    ⚡ Rayo + nodos de circuito
├── machine_learning.svg        🧠 Red neuronal
├── redes_distribucion.svg      🗺️ Nodos conectados (P₁,P₂,P₃,P₄)
├── ecuaciones_diferenciales.svg 🔬 Curva + malla de puntos
├── sistema_axb.svg             🔢 Matriz [A]x = b
├── memoria_eficiente.svg       ⚡ Chip RAM con ✓
├── convergencia.svg            🎯 Diana con camino de convergencia
└── descenso_gradiente.svg      📉 Cuenco con puntos de descenso

📁 iconos/png/
└── (los mismos en formato PNG 256×256)
"""
